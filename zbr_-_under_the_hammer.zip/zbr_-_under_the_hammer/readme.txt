Short:	  "Under the Hammer" AGA Demo by Zaborra.
Author:	  Zaborra
Uploader: calamo@ctv.es  (Estrayk/Capsule)
Type:	  /demo/aga/

Zaborra presents a demo called "Under the Hammer" released at 
"The Saturne Party III" held 26-28/04/96 in Paris, but the dead-line
caught us and was impossible present this production for the compo. :-(

This Demo is Public Domain and may freely be spread around
the globe. This file must be spread along with the demo.

This product may NOT be sold to gain any profit without a
written agreement from the authours.

Zaborra can NOT be held responsible for any damage
caused to your system when executing the demo.

The demo works on a standard Amiga 1200 with 2 MB fast memory
but for optimum satisfaction an accelerator board is highly
recommended like a Blizzard A1230/50 or a 1260/50. :-D

Hardware requirements:  MC68020 AGA chipset.
                        1 Megs of Chip Ram.
                        2 Megs of Fast Ram.
                        1.7 Megs of HD space

Hardware recommended:   MC68030 50Mhz or MC68060 50MHz

Installation:   Unpack the lha-archive into your demos drawer and
                click on the icon.


       Greets... from   Peskanov Of Zaborra & Estrayk Of Capsule

                                          Spanish Light in 1996.

